import React, { useState } from 'react';

var DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

var LOCATIONS = [
  { id: 'alpharetta', name: 'Alpharetta', color: '#378ADD', light: '#E6F1FB' },
  { id: 'duluth',     name: 'Duluth',     color: '#1D9E75', light: '#E1F5EE' },
  { id: 'brentwood',  name: 'Brentwood',  color: '#D85A30', light: '#FAECE7' },
  { id: 'orlando',    name: 'Orlando',    color: '#9B59B6', light: '#F3E8FF' },
  { id: 'tomsriver',  name: 'Toms River', color: '#BA7517', light: '#FAEEDA' },
  { id: 'millbury',   name: 'Millbury',   color: '#D4537E', light: '#FBEAF0' }
];

var DEFAULT_CLEANERS = [
  { id: 'a1', name: 'Cleaner A1', locationId: 'alpharetta' },
  { id: 'a2', name: 'Cleaner A2', locationId: 'alpharetta' },
  { id: 'a3', name: 'Weekend A',  locationId: 'alpharetta' },
  { id: 'd1', name: 'Cleaner D1', locationId: 'duluth' },
  { id: 'd2', name: 'Cleaner D2', locationId: 'duluth' },
  { id: 'd3', name: 'Weekend D',  locationId: 'duluth' },
  { id: 'b1', name: 'Cleaner B1', locationId: 'brentwood' },
  { id: 'o1', name: 'Cleaner O1', locationId: 'orlando' },
  { id: 'o2', name: 'Cleaner O2', locationId: 'orlando' },
  { id: 'o3', name: 'Weekend O1', locationId: 'orlando' },
  { id: 'o4', name: 'Weekend O2', locationId: 'orlando' },
  { id: 't1', name: 'Cleaner T1', locationId: 'tomsriver' },
  { id: 't2', name: 'Cleaner T2', locationId: 'tomsriver' },
  { id: 't3', name: 'Cleaner T3', locationId: 'tomsriver' },
  { id: 't4', name: 'Cleaner T4', locationId: 'tomsriver' },
  { id: 't5', name: 'Cleaner T5', locationId: 'tomsriver' },
  { id: 't6', name: 'Cleaner T6', locationId: 'tomsriver' },
  { id: 't7', name: 'Weekend T',  locationId: 'tomsriver' },
  { id: 'm1', name: 'Cleaner M1', locationId: 'millbury' },
  { id: 'm2', name: 'Cleaner M2', locationId: 'millbury' },
  { id: 'm3', name: 'Cleaner M3', locationId: 'millbury' },
  { id: 'm4', name: 'Cleaner M4', locationId: 'millbury' }
];

var DEFAULT_SHIFTS = {
  a1: { Mon:'8:00-2:00',  Tue:'8:00-2:00',  Wed:'8:00-2:00',  Thu:'8:00-2:00',  Fri:'8:00-2:00',  Sat:'',         Sun:'' },
  a2: { Mon:'12:00-6:00', Tue:'12:00-6:00', Wed:'12:00-6:00', Thu:'12:00-6:00', Fri:'12:00-6:00', Sat:'',         Sun:'' },
  a3: { Mon:'',           Tue:'',           Wed:'',           Thu:'',           Fri:'',           Sat:'8:00-6:00', Sun:'8:00-6:00' },
  d1: { Mon:'8:00-2:00',  Tue:'8:00-2:00',  Wed:'8:00-2:00',  Thu:'8:00-2:00',  Fri:'8:00-2:00',  Sat:'',         Sun:'' },
  d2: { Mon:'12:00-6:00', Tue:'12:00-6:00', Wed:'12:00-6:00', Thu:'12:00-6:00', Fri:'12:00-6:00', Sat:'',         Sun:'' },
  d3: { Mon:'',           Tue:'',           Wed:'',           Thu:'',           Fri:'',           Sat:'8:00-6:00', Sun:'8:00-6:00' },
  b1: { Mon:'9:00-3:00',  Tue:'9:00-3:00',  Wed:'9:00-3:00',  Thu:'9:00-3:00',  Fri:'9:00-3:00',  Sat:'9:00-3:00', Sun:'9:00-3:00' },
  o1: { Mon:'7:00-2:00',  Tue:'7:00-2:00',  Wed:'7:00-2:00',  Thu:'7:00-2:00',  Fri:'7:00-2:00',  Sat:'',         Sun:'' },
  o2: { Mon:'8:00-3:00',  Tue:'8:00-3:00',  Wed:'8:00-3:00',  Thu:'8:00-3:00',  Fri:'8:00-3:00',  Sat:'',         Sun:'' },
  o3: { Mon:'',           Tue:'',           Wed:'',           Thu:'',           Fri:'',           Sat:'8:00-3:00', Sun:'8:00-3:00' },
  o4: { Mon:'',           Tue:'',           Wed:'',           Thu:'',           Fri:'',           Sat:'8:00-3:00', Sun:'8:00-3:00' },
  t1: { Mon:'8:00-2:00',  Tue:'8:00-2:00',  Wed:'8:00-2:00',  Thu:'8:00-2:00',  Fri:'8:00-2:00',  Sat:'',         Sun:'' },
  t2: { Mon:'12:00-6:00', Tue:'12:00-6:00', Wed:'12:00-6:00', Thu:'12:00-6:00', Fri:'12:00-6:00', Sat:'',         Sun:'' },
  t3: { Mon:'8:00-2:00',  Tue:'8:00-2:00',  Wed:'8:00-2:00',  Thu:'8:00-2:00',  Fri:'8:00-2:00',  Sat:'',         Sun:'' },
  t4: { Mon:'12:00-6:00', Tue:'12:00-6:00', Wed:'12:00-6:00', Thu:'12:00-6:00', Fri:'12:00-6:00', Sat:'',         Sun:'' },
  t5: { Mon:'8:00-2:00',  Tue:'8:00-2:00',  Wed:'8:00-2:00',  Thu:'8:00-2:00',  Fri:'8:00-2:00',  Sat:'',         Sun:'' },
  t6: { Mon:'12:00-6:00', Tue:'12:00-6:00', Wed:'12:00-6:00', Thu:'12:00-6:00', Fri:'12:00-6:00', Sat:'',         Sun:'' },
  t7: { Mon:'',           Tue:'',           Wed:'',           Thu:'',           Fri:'',           Sat:'8:00-6:00', Sun:'8:00-6:00' },
  m1: { Mon:'7:00-1:00',  Tue:'7:00-1:00',  Wed:'7:00-1:00',  Thu:'7:00-1:00',  Fri:'7:00-1:00',  Sat:'7:00-1:00', Sun:'7:00-1:00' },
  m2: { Mon:'7:00-1:00',  Tue:'7:00-1:00',  Wed:'7:00-1:00',  Thu:'7:00-1:00',  Fri:'7:00-1:00',  Sat:'7:00-1:00', Sun:'7:00-1:00' },
  m3: { Mon:'10:00-4:00', Tue:'10:00-4:00', Wed:'10:00-4:00', Thu:'10:00-4:00', Fri:'10:00-4:00', Sat:'10:00-4:00', Sun:'10:00-4:00' },
  m4: { Mon:'10:00-4:00', Tue:'10:00-4:00', Wed:'10:00-4:00', Thu:'10:00-4:00', Fri:'10:00-4:00', Sat:'10:00-4:00', Sun:'10:00-4:00' }
};

function loadStorage(key, fallback) {
  try {
    var val = localStorage.getItem(key);
    return val ? JSON.parse(val) : fallback;
  } catch (e) {
    return fallback;
  }
}

function saveStorage(key, val) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
}

function getMonday(offsetWeeks) {
  var now = new Date();
  var day = now.getDay();
  var diff = now.getDate() - day + (day === 0 ? -6 : 1) + offsetWeeks * 7;
  var mon = new Date(now);
  mon.setDate(diff);
  mon.setHours(0,0,0,0);
  return mon;
}

function weekKey(offsetWeeks) {
  return getMonday(offsetWeeks).toISOString().slice(0,10);
}

function weekLabel(offsetWeeks) {
  var mon = getMonday(offsetWeeks);
  var sun = new Date(mon);
  sun.setDate(mon.getDate() + 6);
  var fmt = function(d) { return d.toLocaleDateString('en-US', { month:'short', day:'numeric' }); };
  return fmt(mon) + ' - ' + fmt(sun);
}

function dayDates(offsetWeeks) {
  var mon = getMonday(offsetWeeks);
  return DAYS.map(function(_, i) {
    var d = new Date(mon);
    d.setDate(mon.getDate() + i);
    return d.getDate();
  });
}

function App() {
  var [cleaners, setCleaners] = useState(function() { return loadStorage('cs_cleaners', DEFAULT_CLEANERS); });
  var [allShifts, setAllShifts] = useState(function() { return loadStorage('cs_shifts', {}); });
  var [weekOffset, setWeekOffset] = useState(0);
  var [editCell, setEditCell] = useState(null);
  var [editNameId, setEditNameId] = useState(null);
  var [filterLoc, setFilterLoc] = useState('all');
  var [collapsed, setCollapsed] = useState({});
  var [focusDay, setFocusDay] = useState(null);
  var [newLoc, setNewLoc] = useState('alpharetta');
  var [savedMsg, setSavedMsg] = useState(false);

  var wk = weekKey(weekOffset);
  var dates = dayDates(weekOffset);
  var shifts = allShifts[wk] || (weekOffset === 0 ? DEFAULT_SHIFTS : {});

  function flash() {
    setSavedMsg(true);
    setTimeout(function() { setSavedMsg(false); }, 1500);
  }

  function updateShift(cid, day, val) {
    var next = Object.assign({}, allShifts);
    next[wk] = Object.assign({}, shifts);
    next[wk][cid] = Object.assign({}, next[wk][cid] || {});
    next[wk][cid][day] = val;
    setAllShifts(next);
    saveStorage('cs_shifts', next);
    flash();
  }

  function updateName(cid, val) {
    var next = cleaners.map(function(c) { return c.id === cid ? Object.assign({}, c, { name: val }) : c; });
    setCleaners(next);
    saveStorage('cs_cleaners', next);
    flash();
  }

  function addCleaner() {
    var id = 'c_' + Date.now();
    var next = cleaners.concat([{ id: id, name: 'New Cleaner', locationId: newLoc }]);
    setCleaners(next);
    saveStorage('cs_cleaners', next);
    setEditNameId(id);
  }

  function removeCleaner(cid) {
    if (!window.confirm('Remove this cleaner?')) return;
    var next = cleaners.filter(function(c) { return c.id !== cid; });
    setCleaners(next);
    saveStorage('cs_cleaners', next);
  }

  function clearWeek(cid) {
    var empty = {};
    DAYS.forEach(function(d) { empty[d] = ''; });
    var next = Object.assign({}, allShifts);
    next[wk] = Object.assign({}, shifts);
    next[wk][cid] = empty;
    setAllShifts(next);
    saveStorage('cs_shifts', next);
    flash();
  }

  function copyToNext() {
    var nextWk = weekKey(weekOffset + 1);
    var next = Object.assign({}, allShifts);
    next[nextWk] = Object.assign({}, shifts);
    setAllShifts(next);
    saveStorage('cs_shifts', next);
    alert('Schedule copied to next week!');
  }

  function toggleCollapse(locId) {
    setCollapsed(function(c) {
      var n = Object.assign({}, c);
      n[locId] = !n[locId];
      return n;
    });
  }

  function countWorking(day) {
    return cleaners.filter(function(c) { return shifts[c.id] && shifts[c.id][day]; }).length;
  }

  var shownDays = focusDay ? [focusDay] : DAYS;
  var shownLocs = filterLoc === 'all' ? LOCATIONS : LOCATIONS.filter(function(l) { return l.id === filterLoc; });
  var locById = {};
  LOCATIONS.forEach(function(l) { locById[l.id] = l; });

  return (
    React.createElement('div', { style: { maxWidth: 980, margin: '0 auto', padding: '20px 14px 60px', fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif", color: '#0f172a' } },

      /* ── Header ── */
      React.createElement('div', { style: { marginBottom: 20, paddingBottom: 16, borderBottom: '1px solid #e5e7eb' } },
        React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12 } },
          React.createElement('div', null,
            React.createElement('p', { style: { fontSize: 11, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.08em', margin: '0 0 2px' } }, 'Cleaning Operations'),
            React.createElement('h1', { style: { fontSize: 22, fontWeight: 700, margin: '0 0 2px' } }, 'Staff Scheduler'),
            React.createElement('p', { style: { fontSize: 13, color: '#6b7280', margin: 0 } }, '6 locations \u00b7 ' + cleaners.length + ' cleaners')
          ),
          React.createElement('div', { style: { display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8 } },
            React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 6 } },
              React.createElement('button', { onClick: function() { setWeekOffset(function(w) { return w - 1; }); }, style: navBtn }, '\u2039'),
              React.createElement('span', { style: { fontSize: 13, fontWeight: 600, minWidth: 160, textAlign: 'center' } }, weekLabel(weekOffset)),
              React.createElement('button', { onClick: function() { setWeekOffset(function(w) { return w + 1; }); }, style: navBtn }, '\u203a'),
              weekOffset !== 0 && React.createElement('button', { onClick: function() { setWeekOffset(0); }, style: Object.assign({}, navBtn, { fontSize: 11, padding: '5px 10px', width: 'auto' }) }, 'Today')
            ),
            React.createElement('div', { style: { display: 'flex', gap: 8, alignItems: 'center' } },
              React.createElement('button', { onClick: copyToNext, style: smallBtn }, 'Copy \u2192 next week'),
              savedMsg && React.createElement('span', { style: { fontSize: 12, color: '#15803d', fontWeight: 500 } }, '\u2713 Saved')
            )
          )
        ),

        /* Day pills */
        React.createElement('div', { style: { display: 'flex', gap: 6, marginTop: 14, flexWrap: 'wrap', alignItems: 'center' } },
          DAYS.map(function(day, i) {
            var count = countWorking(day);
            var active = focusDay === day;
            var isWe = i >= 5;
            return React.createElement('button', {
              key: day,
              onClick: function() { setFocusDay(active ? null : day); },
              style: {
                display: 'flex', alignItems: 'center', gap: 5, padding: '5px 10px', borderRadius: 20,
                cursor: 'pointer', fontFamily: 'inherit',
                border: active ? '1.5px solid #3b82f6' : '1px solid #e5e7eb',
                background: active ? '#eff6ff' : isWe ? '#f9fafb' : '#fff',
                color: active ? '#1d4ed8' : '#6b7280'
              }
            },
              React.createElement('span', { style: { fontSize: 12, fontWeight: 600 } }, day),
              React.createElement('span', { style: { fontSize: 11 } }, dates[i]),
              React.createElement('span', { style: { fontSize: 11, fontWeight: 600, background: count > 0 ? '#dcfce7' : '#f3f4f6', color: count > 0 ? '#15803d' : '#9ca3af', padding: '1px 6px', borderRadius: 10 } }, count)
            );
          }),
          React.createElement('span', { style: { fontSize: 11, color: '#9ca3af', marginLeft: 4 } }, 'working per day')
        )
      ),

      /* ── Filters + Add ── */
      React.createElement('div', { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 10 } },
        React.createElement('div', { style: { display: 'flex', gap: 6, flexWrap: 'wrap' } },
          ['all'].concat(LOCATIONS.map(function(l) { return l.id; })).map(function(id) {
            var loc = locById[id];
            var active = filterLoc === id;
            return React.createElement('button', {
              key: id,
              onClick: function() { setFilterLoc(id); },
              style: {
                padding: '5px 12px', borderRadius: 20, fontSize: 12, cursor: 'pointer', fontWeight: active ? 600 : 400, fontFamily: 'inherit',
                background: active ? (loc ? loc.light : '#f1f5f9') : 'transparent',
                border: '1px solid ' + (active ? (loc ? loc.color : '#94a3b8') : '#e5e7eb'),
                color: active ? (loc ? loc.color : '#0f172a') : '#6b7280'
              }
            }, id === 'all' ? 'All locations' : loc.name);
          })
        ),
        React.createElement('div', { style: { display: 'flex', gap: 8, alignItems: 'center' } },
          React.createElement('select', { value: newLoc, onChange: function(e) { setNewLoc(e.target.value); }, style: { fontSize: 12, padding: '6px 8px', borderRadius: 8, border: '1px solid #d1d5db', fontFamily: 'inherit' } },
            LOCATIONS.map(function(l) { return React.createElement('option', { key: l.id, value: l.id }, l.name); })
          ),
          React.createElement('button', { onClick: addCleaner, style: addBtn }, '+ Add cleaner')
        )
      ),

      /* ── Location sections ── */
      shownLocs.map(function(loc) {
        var locCleaners = cleaners.filter(function(c) { return c.locationId === loc.id; });
        if (!locCleaners.length) return null;
        var isCollapsed = collapsed[loc.id];

        return React.createElement('div', { key: loc.id, style: { marginBottom: 16, border: '1px solid #e5e7eb', borderRadius: 12, overflow: 'hidden' } },

          /* Location header */
          React.createElement('div', {
            onClick: function() { toggleCollapse(loc.id); },
            style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', background: loc.light, cursor: 'pointer', borderBottom: isCollapsed ? 'none' : '1px solid #e5e7eb' }
          },
            React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 10 } },
              React.createElement('span', { style: { width: 10, height: 10, borderRadius: '50%', background: loc.color, display: 'inline-block' } }),
              React.createElement('span', { style: { fontWeight: 700, fontSize: 14 } }, loc.name),
              React.createElement('span', { style: { fontSize: 12, color: '#6b7280' } }, locCleaners.length + ' cleaner' + (locCleaners.length !== 1 ? 's' : ''))
            ),
            React.createElement('span', { style: { fontSize: 12, color: '#6b7280' } }, isCollapsed ? '\u25bc' : '\u25b2')
          ),

          /* Table */
          !isCollapsed && React.createElement('div', { style: { overflowX: 'auto' } },
            React.createElement('table', { style: { width: '100%', borderCollapse: 'collapse', minWidth: focusDay ? 260 : 660 } },
              React.createElement('thead', null,
                React.createElement('tr', { style: { background: '#f8fafc' } },
                  React.createElement('th', { style: th(140, false, false) }, 'Cleaner'),
                  shownDays.map(function(day) {
                    var ri = DAYS.indexOf(day);
                    return React.createElement('th', { key: day, style: th(null, true, ri >= 5) },
                      day + ' ',
                      React.createElement('span', { style: { fontWeight: 400, color: '#9ca3af' } }, dates[ri])
                    );
                  }),
                  React.createElement('th', { style: th(56, false, false) })
                )
              ),
              React.createElement('tbody', null,
                locCleaners.map(function(cleaner, ci) {
                  var rowBg = ci % 2 === 0 ? '#fff' : '#fafafa';
                  return React.createElement('tr', { key: cleaner.id, style: { borderBottom: '1px solid #f1f5f9', background: rowBg } },

                    /* Name */
                    React.createElement('td', { style: { padding: '6px 14px' } },
                      editNameId === cleaner.id
                        ? React.createElement('input', {
                            autoFocus: true,
                            defaultValue: cleaner.name,
                            onBlur: function(e) { updateName(cleaner.id, e.target.value); setEditNameId(null); },
                            onKeyDown: function(e) { if (e.key === 'Enter') { updateName(cleaner.id, e.target.value); setEditNameId(null); } if (e.key === 'Escape') setEditNameId(null); },
                            style: { fontSize: 13, width: '100%', padding: '4px 6px', borderRadius: 6, border: '1.5px solid ' + loc.color, outline: 'none', fontFamily: 'inherit' }
                          })
                        : React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 6 } },
                            React.createElement('span', { style: { width: 6, height: 6, borderRadius: '50%', background: loc.color, display: 'inline-block', flexShrink: 0 } }),
                            React.createElement('span', {
                              onClick: function() { setEditNameId(cleaner.id); },
                              style: { fontSize: 13, cursor: 'text', borderBottom: '1px dashed #d1d5db' }
                            }, cleaner.name)
                          )
                    ),

                    /* Shift cells */
                    shownDays.map(function(day) {
                      var ri = DAYS.indexOf(day);
                      var val = (shifts[cleaner.id] && shifts[cleaner.id][day]) || '';
                      var isEditing = editCell && editCell.cid === cleaner.id && editCell.day === day;
                      var weBg = ri >= 5 ? (ci % 2 === 0 ? '#f9f9f9' : '#f3f3f3') : 'inherit';
                      return React.createElement('td', { key: day, style: { padding: '4px 5px', textAlign: 'center', background: weBg } },
                        isEditing
                          ? React.createElement('input', {
                              autoFocus: true,
                              defaultValue: val,
                              placeholder: '8:00-4:00',
                              onBlur: function(e) { updateShift(cleaner.id, day, e.target.value); setEditCell(null); },
                              onKeyDown: function(e) { if (e.key === 'Enter') { updateShift(cleaner.id, day, e.target.value); setEditCell(null); } if (e.key === 'Escape') setEditCell(null); },
                              style: { fontSize: 11, width: '100%', padding: '4px 4px', borderRadius: 6, border: '1.5px solid ' + loc.color, textAlign: 'center', outline: 'none', fontFamily: 'inherit' }
                            })
                          : React.createElement('div', {
                              onClick: function() { setEditCell({ cid: cleaner.id, day: day }); },
                              style: {
                                fontSize: 11, padding: '5px 3px', borderRadius: 6, cursor: 'pointer', minHeight: 28,
                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                background: val ? loc.light : 'transparent',
                                color: val ? loc.color : '#d1d5db',
                                border: val ? '1px solid ' + loc.color + '55' : '1px dashed #e5e7eb',
                                fontWeight: val ? 600 : 400
                              }
                            }, val || React.createElement('span', { style: { fontSize: 10 } }, 'off'))
                      );
                    }),

                    /* Actions */
                    React.createElement('td', { style: { padding: '4px 8px' } },
                      React.createElement('div', { style: { display: 'flex', gap: 3, justifyContent: 'center' } },
                        React.createElement('button', { title: 'Clear week', onClick: function() { clearWeek(cleaner.id); }, style: iBtn('#6b7280') }, '\u2715'),
                        React.createElement('button', { title: 'Remove', onClick: function() { removeCleaner(cleaner.id); }, style: iBtn('#dc2626') }, '\u2212')
                      )
                    )
                  );
                })
              )
            )
          )
        );
      }),

      /* ── Footer ── */
      React.createElement('div', { style: { marginTop: 20, padding: '12px 16px', background: '#f8fafc', borderRadius: 8, fontSize: 12, color: '#9ca3af' } },
        'Click any shift to edit \u00b7 Click a name to rename \u00b7 \u2715 clears the week \u00b7 All changes auto-save'
      )
    )
  );
}

var navBtn = { width: 32, height: 32, borderRadius: 8, border: '1px solid #e5e7eb', background: '#fff', cursor: 'pointer', fontSize: 18, color: '#374151', fontFamily: 'inherit' };
var smallBtn = { fontSize: 12, padding: '6px 12px', borderRadius: 8, border: '1px solid #d1d5db', background: '#fff', cursor: 'pointer', color: '#374151', fontFamily: 'inherit' };
var addBtn = { fontSize: 12, padding: '6px 14px', borderRadius: 8, border: '1px solid #0f172a', background: '#0f172a', cursor: 'pointer', color: '#fff', fontWeight: 600, fontFamily: 'inherit' };
function th(w, center, weekend) {
  return { padding: '8px 10px', textAlign: center ? 'center' : 'left', fontSize: 11, fontWeight: 600, color: '#6b7280', borderBottom: '1px solid #e5e7eb', width: w || undefined, background: weekend ? '#f3f4f6' : '#f8fafc', whiteSpace: 'nowrap' };
}
function iBtn(color) {
  return { width: 24, height: 24, borderRadius: 4, border: '1px solid #e5e7eb', background: 'transparent', cursor: 'pointer', fontSize: 12, color: color, fontFamily: 'inherit', display: 'flex', alignItems: 'center', justifyContent: 'center' };
}

export default App;
